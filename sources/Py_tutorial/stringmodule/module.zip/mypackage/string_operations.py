"""
Module for basic string operations.
"""

def concatenate(str1, str2):
    return str1 + str2

def split_string(string, delimiter=" "):
    return string.split(delimiter)
