"""
Helper functions for advanced mathematical operations.
"""

def multiply(a, b):
    return a * b

def divide(a, b):
    return a / b if b != 0 else "Division by zero!"
