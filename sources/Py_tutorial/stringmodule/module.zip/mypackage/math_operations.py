"""
Module for basic mathematical operations.
"""

def add(a, b):
    return a + b

def subtract(a, b):
    return a - b
