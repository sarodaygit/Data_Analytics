"""
This is the main package for various utility functions.
"""

# Optional: Specify what to expose when using `from my_package import *`
__all__ = ["math_operations", "string_operations", "utilities"]
